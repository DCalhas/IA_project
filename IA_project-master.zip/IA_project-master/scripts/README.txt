
Altera��es na vers�o 0.3 (06-octubro-2016)

Algumas d�vidas de alguns alunos.

1. Como se calcula o custo no nextstate?

O custo � o custo da �ltima ac��o e n�o o custo total acumulado (isso ir� aparecer no n� na fun��o g)

2. Quando h� acidente o que acontece?

O agente fica logo na posi��o inicial, n�o precisa de esperar mais uma ac��o.


Altera��es no enunciado e scripts.

a) Clarificar o c�lculo da velocidade.

b) Clarificar o c�lculo do custo.

c) Links para criar grupos no mooshak.

d) Correc��o de typo na fun��o nextstate.

e) Correc��o de typo nos par�metros da fun��o isgoalp.

f) Correc��o nos loads iniciais do ficheiro solF1.lisp


